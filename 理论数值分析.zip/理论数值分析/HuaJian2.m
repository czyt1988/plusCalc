syms P1(0) p0 c u1(0) P2(0) u2(0) P1(lp2) u1(lp2) P2(lp2) u2(lp2) lb1 lp2 k i

P2(0) = (p0.*c.*u2(0))./(-1.*i.*tan(k.*lb1));
P2(lp2) = (p0.*c.*u2(lp2))./(-1.*i.*tan(k.*(lb1+lp2)));

eq1 = R11.*P1(lp2) + R12.*p0.*c.*u1(lp2) + R13.*P2(lp2) + R14.*p0.*c.*u2(lp2) - P1(0);
eq2 = R21.*P1(lp2) + R22.*p0.*c.*u1(lp2) + R23.*P2(lp2) + R24.*p0.*c.*u2(lp2) - p0.*c.*u1(0);
eq3 = R31.*P1(lp2) + R32.*p0.*c.*u1(lp2) + R33.*P2(lp2) + R34.*p0.*c.*u2(lp2) - P2(0);
eq4 = R41.*P1(lp2) + R42.*p0.*c.*u1(lp2) + R43.*P2(lp2) + R44.*p0.*c.*u2(lp2) - p0.*c.*u2(0);

D = solve(eq1,eq2,eq3,eq4,P1(0),u2(0));

P1(0) = D.P1(0)
u2(0) = D.u2(0)
